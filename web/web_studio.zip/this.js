function processDuck() {
  alert(this.value + "is checked!");
}
d1.onclick = processDuck;
d2.onclick = processDuck;
d3.onclick = processDuck;
