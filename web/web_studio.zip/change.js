
function change(){
  document.getElementById("demo").innerHTML = "change!";
  document.getElementById("demo").style = "color : red";
}

function write(){
  document.getElementById("demo2").innerHTML = "write";
}


function excute(){
  test.onclick = change;
  test2.onclick = write;
//  caution()
  //document.getElementById("test").onclick = change;
}

//window.onload = excute;
// caution window.onLoad = excute;

/*
// anonymous function
// dont forget ;
window.onload = function(){
  var button = document.getElementById("test");
  button.onclick = boom;
  button.onclick = function(){alert("hello")};
};
function boom(){
  alert("hello");
}
*/

//test.onclick = change;
//test2.onclick = write;
//change;
