//
//  ViewController.swift
//  WeatherTable
//
//  Created by Dongheon Ryu on 2017. 2. 17..
//  Copyright © 2017년 Dongheon Ryu. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource {

    var datalist :[[String:String]] = [[:]]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datalist.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        var dicTemp = datalist[indexPath.row]
        
        cell.textLabel!.text = dicTemp["location"]
        
        let weatherStr = dicTemp["weather"]
        
        cell.detailTextLabel!.text = weatherStr
        
        if weatherStr == "rain"{
            cell.imageView!.image = UIImage(named: "1.jpg")
        }
        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
                let dict1 = ["location":"KOREA","weather":"rain"]
                let dict2 = ["location":"KOREA","weather":"rain"]
                let dict3 = ["location":"KOREA","weather":"rain"]
                let dict4 = ["location":"KOREA","weather":"rain"]
                let dict5 = ["location":"KOREA","weather":"rain"]
                let dict6 = ["location":"KOREA","weather":"rain"]
        datalist = [dict1,dict2,dict3,dict4,dict5,dict6]
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

