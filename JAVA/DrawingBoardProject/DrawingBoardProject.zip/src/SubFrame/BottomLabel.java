package SubFrame;

import java.awt.Color;

import javax.swing.JLabel;

public class BottomLabel extends JLabel{
	
	public BottomLabel(String name)
	{
		super(name);
		setBackground(Color.DARK_GRAY);
		setVisible(true);
	}

}
